require('dotenv').config();

/**
 * Central config — every other file reads bot settings from here.
 * Nothing about WhatsApp linking/credentials lives in source files;
 * it all comes from .env so you can redeploy without editing code.
 */
module.exports = {
  phoneNumber: (process.env.PHONE_NUMBER || '').replace(/[^0-9]/g, ''),
  prefix: process.env.PREFIX || '.',
  botName: process.env.BOT_NAME || 'Amv Wp Bot',
  ownerNumber: (process.env.OWNER_NUMBER || process.env.PHONE_NUMBER || '').replace(/[^0-9]/g, ''),
};
