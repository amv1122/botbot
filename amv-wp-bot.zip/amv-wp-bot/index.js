const makeWASocket = require('baileys').default;
const {
  useMultiFileAuthState,
  fetchLatestBaileysVersion,
  DisconnectReason,
} = require('baileys');
const { Boom } = require('@hapi/boom');
const pino = require('pino');

const config = require('./config');
const { loadCommands } = require('./commandLoader');

const logger = pino({ level: 'silent' }); // set to 'info' or 'debug' if you need verbose Baileys logs
const commands = loadCommands();

console.log(`[${config.botName}] Loaded ${new Set([...commands.values()].map((c) => c.name)).size} commands.`);

const MAX_RECONNECT_ATTEMPTS = 10;
let reconnectAttempts = 0;

async function startBot() {
  const { state, saveCreds } = await useMultiFileAuthState('auth_info');
  const { version } = await fetchLatestBaileysVersion();

  const sock = makeWASocket({
    version,
    auth: state,
    logger,
    printQRInTerminal: false, // we use pairing code, not QR
    browser: ['Ubuntu', 'Chrome', '20.0.04'],
  });

  // ── Pairing code flow ────────────────────────────────────
  // Only request a pairing code if we are not already registered/linked.
  if (!sock.authState.creds.registered) {
    if (!config.phoneNumber) {
      console.error('❌ PHONE_NUMBER is not set in .env. Add it and restart.');
      process.exit(1);
    }

    // Baileys needs a brief moment after socket creation before it will
    // accept a pairing code request.
    setTimeout(async () => {
      try {
        const code = await sock.requestPairingCode(config.phoneNumber);
        console.log('\n========================================');
        console.log(` Pairing code for +${config.phoneNumber}:`);
        console.log(`   ${code}`);
        console.log(' On your phone: WhatsApp → Settings →');
        console.log(' Linked Devices → Link a Device →');
        console.log(' "Link with phone number instead" → enter this code.');
        console.log('========================================\n');
      } catch (err) {
        console.error('❌ Failed to request pairing code:', err);
      }
    }, 3000);
  }

  // ── Connection lifecycle ─────────────────────────────────
  sock.ev.on('connection.update', (update) => {
    const { connection, lastDisconnect } = update;

    if (connection === 'open') {
      reconnectAttempts = 0; // reset the counter once we're actually connected
      console.log(`✅ ${config.botName} connected to WhatsApp.`);
    }

    if (connection === 'close') {
      const statusCode = new Boom(lastDisconnect?.error)?.output?.statusCode;
      const loggedOut = statusCode === DisconnectReason.loggedOut;

      if (loggedOut) {
        console.log('❌ Session logged out. Delete the "auth_info" folder and restart to relink.');
        return;
      }

      reconnectAttempts += 1;

      if (reconnectAttempts > MAX_RECONNECT_ATTEMPTS) {
        console.error(
          `❌ Gave up after ${MAX_RECONNECT_ATTEMPTS} reconnect attempts. ` +
            'If running under pm2, it will restart the whole process; otherwise restart manually.'
        );
        process.exit(1);
        return;
      }

      // Exponential-ish backoff capped at 30s, so a flapping connection
      // doesn't spawn sockets in a tight loop.
      const delayMs = Math.min(30000, 2000 * reconnectAttempts);
      console.log(
        `⚠️ Connection closed (attempt ${reconnectAttempts}/${MAX_RECONNECT_ATTEMPTS}), ` +
          `reconnecting in ${delayMs / 1000}s...`
      );
      setTimeout(() => startBot(), delayMs);
    }
  });

  sock.ev.on('creds.update', saveCreds);

  // ── Incoming messages ────────────────────────────────────
  sock.ev.on('messages.upsert', async ({ messages, type }) => {
    if (type !== 'notify') return;

    const msg = messages[0];
    if (!msg.message || msg.key.fromMe) return;

    const jid = msg.key.remoteJid;
    const body =
      msg.message.conversation ||
      msg.message.extendedTextMessage?.text ||
      msg.message.imageMessage?.caption ||
      msg.message.videoMessage?.caption ||
      '';

    if (!body.startsWith(config.prefix)) return;

    const withoutPrefix = body.slice(config.prefix.length).trim();
    const [commandName, ...args] = withoutPrefix.split(/\s+/);
    const command = commands.get(commandName.toLowerCase());

    if (!command) return; // not a recognized command — stay silent

    try {
      await command.execute({
        sock,
        msg,
        jid,
        args,
        commands,
        botName: config.botName,
        prefix: config.prefix,
        ownerNumber: config.ownerNumber,
      });
    } catch (err) {
      console.error(`[command:${command.name}] Error:`, err);
      await sock.sendMessage(jid, { text: '⚠️ Something went wrong running that command.' });
    }
  });

  return sock;
}

startBot().catch((err) => {
  console.error('Fatal error starting bot:', err);
  process.exit(1);
});
