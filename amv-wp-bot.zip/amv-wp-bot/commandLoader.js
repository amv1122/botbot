const fs = require('fs');
const path = require('path');

/**
 * Loads every command module from /commands into a single Map.
 * Each command file must export: { name, aliases?, description, execute(ctx) }
 *
 * To add a new command later: drop a new file in /commands that follows
 * the same shape — it will be picked up automatically, no edits needed here.
 */
function loadCommands() {
  const commands = new Map();
  const commandsDir = path.join(__dirname, 'commands');
  const files = fs.readdirSync(commandsDir).filter((f) => f.endsWith('.js'));

  for (const file of files) {
    let command;

    try {
      command = require(path.join(commandsDir, file));
    } catch (err) {
      console.warn(`[commands] Failed to load "${file}": ${err.message}`);
      continue;
    }

    if (!command.name || typeof command.execute !== 'function') {
      console.warn(`[commands] Skipping "${file}" — missing "name" or "execute".`);
      continue;
    }

    commands.set(command.name.toLowerCase(), command);

    if (Array.isArray(command.aliases)) {
      for (const alias of command.aliases) {
        commands.set(alias.toLowerCase(), command);
      }
    }
  }

  return commands;
}

module.exports = { loadCommands };
